
+ Add to git
+ migrate database using bastion ec2
+ bundle app.zip. Create script for it
+ run truedata save to db
- Add trades mailing
- Add required data to db. Seeding
- Run with trades mailing
- Rollover