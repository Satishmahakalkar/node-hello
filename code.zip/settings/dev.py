
TORTOISE_ORM = {
    "connections": {
        "default": "sqlite://db.sqlite3",
    },
    "apps": {
        "models": {
            "models": ["database.models", "aerich.models"],
            "default_connection": "default"
        },
    },
}


TRUEDATA_USERNAME = ...
TRUEDATA_PASSWORD = ...